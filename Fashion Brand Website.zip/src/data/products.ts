export type Product = {
  id: string;
  name: string;
  category: "Women" | "Men";
  type: string;
  price: number;
  color: string;
  description: string;
  details: string[];
  sizes: string[];
  images: string[];
};

const photo = (id: string, width = 1200) =>
  `https://images.unsplash.com/${id}?auto=format&fit=crop&w=${width}&q=88`;

export const products: Product[] = [
  {
    id: "neel-kurta",
    name: "The Neel Kurta",
    category: "Women",
    type: "Kurtas",
    price: 38500,
    color: "Indigo",
    description:
      "A fluid, elongated kurta cut in handwoven silk, finished with tonal embroidery and a sculptural side slit.",
    details: ["Handwoven silk", "Tonal hand embroidery", "Made in India", "Dry clean only"],
    sizes: ["XS", "S", "M", "L", "XL"],
    images: [
      photo("photo-1786596552022-9ba8f6fbab92"),
      photo("photo-1597533456455-39defa5bf390"),
    ],
  },
  {
    id: "noor-drape",
    name: "Noor Drape",
    category: "Women",
    type: "Drapes",
    price: 42000,
    color: "Ivory",
    description:
      "An effortless draped silhouette in soft silk, balancing classical volume with a pared-back modern line.",
    details: ["Silk crepe", "Hand-finished edges", "Made in India", "Dry clean only"],
    sizes: ["XS", "S", "M", "L"],
    images: [
      photo("photo-1699787167971-db840f61c3bd"),
      photo("photo-1560463023-df5d96fa4e1b"),
    ],
  },
  {
    id: "zari-jacket",
    name: "Zari Evening Jacket",
    category: "Women",
    type: "Jackets",
    price: 68000,
    color: "Antique Gold",
    description:
      "A precise evening jacket with an architectural shoulder, traced with hand-worked antique zari.",
    details: ["Silk brocade", "Hand-worked zari", "Silk lining", "Made in India"],
    sizes: ["XS", "S", "M", "L"],
    images: [
      photo("photo-1702651419103-72b50df2a037"),
      photo("photo-1594994043792-d59be260baea"),
    ],
  },
  {
    id: "rekha-sari",
    name: "Rekha Sari",
    category: "Women",
    type: "Saris",
    price: 52000,
    color: "Vermilion",
    description:
      "A quietly dramatic sari woven with a fine metallic border and a weightless, translucent fall.",
    details: ["Handloom silk organza", "Metallic woven border", "Made in India", "Blouse fabric included"],
    sizes: ["One size"],
    images: [
      photo("photo-1708182564325-fb1d3a3864d3"),
      photo("photo-1561060511-dc6d28b71f8b"),
    ],
  },
  {
    id: "aarav-bandhgala",
    name: "Aarav Bandhgala",
    category: "Men",
    type: "Jackets",
    price: 57500,
    color: "Midnight",
    description:
      "A disciplined bandhgala in deep midnight wool-silk, with a close collar and discreet hand finishing.",
    details: ["Wool-silk blend", "Horn buttons", "Cupro lining", "Made in India"],
    sizes: ["36", "38", "40", "42", "44"],
    images: [
      photo("photo-1759567066672-4b9f48000096"),
      photo("photo-1594994041647-72ef751849d1"),
    ],
  },
  {
    id: "safed-kurta",
    name: "Safed Kurta",
    category: "Men",
    type: "Kurtas",
    price: 28500,
    color: "Chalk",
    description:
      "A clean longline kurta in textured handloom cotton, softened through considered volume and movement.",
    details: ["Handloom cotton", "French seams", "Mother-of-pearl buttons", "Made in India"],
    sizes: ["36", "38", "40", "42", "44"],
    images: [
      photo("photo-1720588713961-1191dd34e23e"),
      photo("photo-1560463023-df5d96fa4e1b"),
    ],
  },
  {
    id: "surkh-kurta",
    name: "Surkh Kurta",
    category: "Men",
    type: "Kurtas",
    price: 32000,
    color: "Madder",
    description:
      "A relaxed silk kurta in saturated madder, designed with an easy shoulder and precise concealed placket.",
    details: ["Matka silk", "Concealed placket", "Side pockets", "Made in India"],
    sizes: ["36", "38", "40", "42", "44"],
    images: [
      photo("photo-1774814323544-99a83ffbcf12"),
      photo("photo-1597533456455-39defa5bf390"),
    ],
  },
  {
    id: "prithvi-set",
    name: "Prithvi Set",
    category: "Men",
    type: "Sets",
    price: 46500,
    color: "Sand",
    description:
      "A tonal two-piece set in slubbed silk, bringing formal restraint to an unstructured, contemporary shape.",
    details: ["Slubbed silk", "Relaxed fit", "Drawstring trouser", "Made in India"],
    sizes: ["36", "38", "40", "42", "44"],
    images: [
      photo("photo-1701365676249-9d7ab5022dec"),
      photo("photo-1655149238677-9b5cb1a0afc6"),
    ],
  },
];

export const formatPrice = (value: number) =>
  new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  }).format(value);
