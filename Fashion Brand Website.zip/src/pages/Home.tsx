import { useState } from "react";

const images = {
  hero: "https://images.unsplash.com/photo-1680506742319-b44ad1c534e0?auto=format&fit=crop&w=1800&q=88",
  architecture:
    "https://images.unsplash.com/photo-1761940546803-ad87f8155b6a?auto=format&fit=crop&w=1200&q=85",
  weaving:
    "https://images.unsplash.com/photo-1640292343595-889db1c8262e?auto=format&fit=crop&w=1400&q=85",
  corridor:
    "https://images.unsplash.com/photo-1786596552022-9ba8f6fbab92?auto=format&fit=crop&w=1400&q=88",
};

const Arrow = () => (
  <svg
    aria-hidden="true"
    className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1"
    fill="none"
    viewBox="0 0 24 24"
  >
    <path d="M5 12h14M14 7l5 5-5 5" stroke="currentColor" strokeLinecap="round" />
  </svg>
);

export default function Home() {
  const [menuOpen, setMenuOpen] = useState(false);

  const closeMenu = () => setMenuOpen(false);

  return (
    <main className="min-h-screen overflow-hidden bg-[#f1ede4] text-[#261d18]">
      <header className="absolute inset-x-0 top-0 z-30 border-b border-white/25 text-white">
        <div className="mx-auto flex h-24 max-w-[1600px] items-center justify-between px-6 md:px-10 lg:px-16">
          <a
            href="#top"
            className="font-display text-center text-[18px] font-semibold leading-[0.82] tracking-[0.16em] uppercase md:text-[21px]"
          >
            House of
            <span className="mt-2 block text-[0.72em] tracking-[0.38em]">Jaswanth</span>
          </a>

          <nav aria-label="Primary navigation" className="hidden items-center gap-10 text-[11px] tracking-[0.2em] uppercase md:flex">
            <a className="nav-link" href="/collections">Collection</a>
            <a className="nav-link" href="/craftsmanship">Craft</a>
            <a className="nav-link" href="/about">Our story</a>
          </nav>

          <div className="hidden items-center gap-7 text-[11px] tracking-[0.2em] uppercase md:flex">
            <a className="nav-link" href="/collections">Search</a>
            <a className="nav-link" href="/appointment">Enquire</a>
          </div>

          <button
            aria-expanded={menuOpen}
            aria-label="Toggle navigation"
            className="flex h-10 w-10 flex-col items-center justify-center gap-1.5 md:hidden"
            onClick={() => setMenuOpen((open) => !open)}
            type="button"
          >
            <span className={`h-px w-5 bg-current transition ${menuOpen ? "translate-y-1 rotate-45" : ""}`} />
            <span className={`h-px w-5 bg-current transition ${menuOpen ? "-translate-y-0.5 -rotate-45" : ""}`} />
          </button>
        </div>

        {menuOpen && (
          <nav className="border-t border-white/20 bg-[#2d1716]/95 px-6 py-8 md:hidden" aria-label="Mobile navigation">
            {["Collection", "Craft", "Our story", "Enquire"].map((item) => (
              <a
                className="block border-b border-white/15 py-4 font-display text-2xl"
                href={item === "Our story" ? "/about" : item === "Collection" ? "/collections" : item === "Craft" ? "/craftsmanship" : "/appointment"}
                key={item}
                onClick={closeMenu}
              >
                {item}
              </a>
            ))}
          </nav>
        )}
      </header>

      <section id="top" className="relative min-h-[760px] bg-[#261614] text-white lg:min-h-screen">
        <img
          alt="Model in a sculptural black ensemble with a sheer veil"
          className="absolute inset-0 h-full w-full object-cover object-[58%_center]"
          src={images.hero}
        />
        <div className="absolute inset-0 bg-[linear-gradient(90deg,rgba(28,12,11,0.78)_0%,rgba(28,12,11,0.26)_55%,rgba(28,12,11,0.08)_100%)]" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#1f1110]/50 via-transparent to-[#1f1110]/25" />

        <div className="relative mx-auto flex min-h-[760px] max-w-[1600px] items-end px-6 pb-16 pt-36 md:px-10 md:pb-20 lg:min-h-screen lg:px-16 lg:pb-24">
          <div className="max-w-[790px] animate-rise">
            <p className="mb-6 text-[10px] tracking-[0.35em] uppercase md:text-xs">
              The inaugural collection · 2025
            </p>
            <h1 className="font-display text-[clamp(4.5rem,10vw,10rem)] font-light leading-[0.75] tracking-[-0.04em]">
              Parampara
            </h1>
            <div className="mt-8 flex flex-col gap-7 border-t border-white/40 pt-7 sm:flex-row sm:items-end sm:justify-between">
              <p className="max-w-sm font-display text-2xl font-light leading-snug md:text-3xl">
                Heritage, recut for a modern life.
              </p>
              <a className="group flex w-fit items-center gap-4 border-b border-white pb-2 text-[11px] tracking-[0.22em] uppercase" href="/collections">
                Discover the collection
                <Arrow />
              </a>
            </div>
          </div>
        </div>

        <p className="absolute bottom-24 right-8 hidden origin-bottom-right rotate-90 text-[9px] tracking-[0.28em] text-white/70 uppercase lg:block">
          New Delhi · India
        </p>
      </section>

      <section id="story" className="relative mx-auto grid max-w-[1600px] gap-16 px-6 py-24 md:px-10 md:py-36 lg:grid-cols-[1fr_1.35fr] lg:px-16 lg:py-44">
        <div>
          <p className="eyebrow">The house</p>
          <p className="mt-24 hidden max-w-[230px] text-xs leading-6 text-[#635650] lg:block">
            Designed in India. Created slowly. Made to endure beyond seasons.
          </p>
        </div>
        <div>
          <h2 className="font-display max-w-4xl text-[clamp(2.8rem,5.5vw,5.8rem)] font-light leading-[0.98] tracking-[-0.035em]">
            A study in restraint, shaped by the richness of Indian craft.
          </h2>
          <div className="mt-12 grid gap-8 border-t border-[#bcb2a7] pt-8 sm:grid-cols-2">
            <p className="max-w-sm text-sm leading-7 text-[#5b4e47]">
              House of Jaswanth brings the depth of traditional textile heritage
              into a contemporary luxury wardrobe—through considered proportion,
              exacting construction, and a quiet sense of permanence.
            </p>
            <a className="group flex h-fit w-fit items-center gap-4 text-[11px] tracking-[0.2em] uppercase sm:justify-self-end" href="/about">
              Enter our world
              <span className="grid h-10 w-10 place-items-center rounded-full border border-[#897c72]">
                <Arrow />
              </span>
            </a>
          </div>
        </div>
      </section>

      <section id="collection" className="bg-[#2d1716] px-6 py-24 text-[#f5f0e7] md:px-10 md:py-32 lg:px-16">
        <div className="mx-auto max-w-[1600px]">
          <div className="flex items-end justify-between border-b border-white/20 pb-8">
            <div>
              <p className="eyebrow !text-[#c9b6a3]">Collection 01</p>
              <h2 className="mt-4 font-display text-5xl font-light tracking-[-0.03em] md:text-7xl">The edit</h2>
            </div>
            <p className="hidden text-[10px] tracking-[0.25em] uppercase sm:block">View all · 18 pieces</p>
          </div>

          <div className="mt-10 grid gap-6 lg:grid-cols-[1.25fr_0.75fr]">
            <article className="group relative min-h-[640px] overflow-hidden md:min-h-[790px]">
              <img
                alt="Woman in an embroidered blue tunic walking through a red stone corridor"
                className="absolute inset-0 h-full w-full object-cover transition duration-700 group-hover:scale-[1.025]"
                src={images.corridor}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/65 via-transparent to-transparent" />
              <div className="absolute inset-x-0 bottom-0 flex items-end justify-between p-7 md:p-10">
                <div>
                  <p className="text-[10px] tracking-[0.25em] uppercase">Look 01</p>
                  <h3 className="mt-2 font-display text-4xl">The Neel Kurta</h3>
                </div>
                <span className="grid h-12 w-12 place-items-center rounded-full border border-white/70">
                  <Arrow />
                </span>
              </div>
            </article>

            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-1">
              <article className="group relative min-h-[380px] overflow-hidden bg-[#d5c0a4]">
                <img
                  alt="Ornate carved archways reflecting India's decorative arts"
                  className="absolute inset-0 h-full w-full object-cover opacity-85 transition duration-700 group-hover:scale-[1.025]"
                  src={images.architecture}
                />
                <div className="absolute inset-0 bg-[#532722]/20" />
                <p className="absolute bottom-7 left-7 text-[10px] tracking-[0.25em] uppercase">A vocabulary of form</p>
              </article>
              <article className="flex min-h-[380px] flex-col justify-between bg-[#c6a969] p-7 text-[#281b16] md:p-10">
                <span className="font-display text-5xl font-light">02</span>
                <div>
                  <p className="mb-4 text-[10px] tracking-[0.25em] uppercase">Made with intention</p>
                  <h3 className="font-display text-4xl leading-tight md:text-5xl">
                    Elegance lives in the details.
                  </h3>
                </div>
              </article>
            </div>
          </div>
        </div>
      </section>

      <section id="craft" className="grid bg-[#ded4c5] lg:grid-cols-2">
        <div className="relative min-h-[520px] lg:min-h-[760px]">
          <img
            alt="Artisan weaving cloth on a traditional handloom"
            className="absolute inset-0 h-full w-full object-cover grayscale-[15%]"
            src={images.weaving}
          />
        </div>
        <div className="flex flex-col justify-center px-6 py-20 md:px-16 lg:px-[10vw]">
          <p className="eyebrow">The hand behind the cloth</p>
          <h2 className="mt-10 font-display text-[clamp(3rem,5vw,5.5rem)] font-light leading-[0.95] tracking-[-0.035em]">
            Crafted slowly.
            <br />
            Worn forever.
          </h2>
          <p className="mt-10 max-w-md text-sm leading-7 text-[#5d5149]">
            We work with skilled makers and storied techniques, allowing the
            character of the hand to remain visible. Every garment is an exchange
            between memory and modernity.
          </p>
          <a className="group mt-10 flex w-fit items-center gap-4 border-b border-[#635650] pb-2 text-[11px] tracking-[0.2em] uppercase" href="/craftsmanship">
            Discover our process
            <Arrow />
          </a>
        </div>
      </section>

      <footer id="contact" className="bg-[#1c1714] px-6 pb-8 pt-24 text-[#eee7dc] md:px-10 md:pt-32 lg:px-16">
        <div className="mx-auto max-w-[1600px]">
          <div className="grid gap-16 border-b border-white/15 pb-20 lg:grid-cols-[1.4fr_0.6fr]">
            <div>
              <p className="eyebrow !text-[#a89c90]">Private appointments & new releases</p>
              <h2 className="mt-7 max-w-3xl font-display text-[clamp(3rem,6.5vw,7rem)] font-light leading-[0.9] tracking-[-0.04em]">
                Join the house.
              </h2>
            </div>
            <form className="self-end" onSubmit={(event) => event.preventDefault()}>
              <label className="text-[10px] tracking-[0.22em] uppercase" htmlFor="email">Email address</label>
              <div className="mt-4 flex border-b border-white/50">
                <input
                  className="min-w-0 flex-1 bg-transparent py-4 text-sm outline-none placeholder:text-white/35"
                  id="email"
                  placeholder="you@example.com"
                  type="email"
                />
                <button aria-label="Submit email" className="group px-3" type="submit"><Arrow /></button>
              </div>
            </form>
          </div>
          <div className="grid gap-10 py-10 text-[10px] tracking-[0.18em] text-white/60 uppercase sm:grid-cols-3">
            <p>© 2025 House of Jaswanth</p>
            <div className="flex gap-6 sm:justify-center">
              <a className="hover:text-white" href="#">Instagram</a>
              <a className="hover:text-white" href="#">Pinterest</a>
            </div>
            <p className="sm:text-right">New Delhi · By appointment</p>
          </div>
        </div>
      </footer>
    </main>
  );
}
