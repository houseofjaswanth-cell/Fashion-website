import { useMemo, useState } from "react";
import { Link, useParams } from "react-router";
import { Arrow, Heart, PrimaryButton } from "../components/Layout";
import { formatPrice, products, type Product } from "../data/products";
import { findProduct, useStore } from "../app/store";

function ProductCard({ product }: { product: Product }) {
  const { wishlist, toggleWishlist } = useStore();
  const saved = wishlist.includes(product.id);
  return (
    <article className="group">
      <div className="relative aspect-[3/4] overflow-hidden bg-[#ded4c5]">
        <Link to={`/product/${product.id}`}>
          <img
            alt={product.name}
            className="h-full w-full object-cover transition duration-700 group-hover:scale-[1.02]"
            src={product.images[0]}
          />
        </Link>
        <button
          aria-label={saved ? "Remove from wishlist" : "Add to wishlist"}
          className="absolute right-4 top-4 grid h-10 w-10 place-items-center rounded-full bg-[#f1ede4]/85 backdrop-blur-sm"
          onClick={() => toggleWishlist(product.id)}
        >
          <Heart filled={saved} />
        </button>
      </div>
      <Link className="mt-4 flex items-start justify-between gap-5" to={`/product/${product.id}`}>
        <div>
          <h2 className="font-display text-xl md:text-2xl">{product.name}</h2>
          <p className="mt-1 text-[9px] tracking-[0.16em] text-[#766960] uppercase">{product.color} · {product.type}</p>
        </div>
        <p className="pt-1 text-xs">{formatPrice(product.price)}</p>
      </Link>
    </article>
  );
}

export function ShopPage({ category }: { category?: "Women" | "Men" }) {
  const [type, setType] = useState("All");
  const [sort, setSort] = useState("Featured");
  const [filtersOpen, setFiltersOpen] = useState(false);
  const types = ["All", ...new Set(products.filter((product) => !category || product.category === category).map((product) => product.type))];
  const visible = useMemo(() => {
    let result = products.filter((product) => (!category || product.category === category) && (type === "All" || product.type === type));
    if (sort === "Price, low to high") result = [...result].sort((a, b) => a.price - b.price);
    if (sort === "Price, high to low") result = [...result].sort((a, b) => b.price - a.price);
    return result;
  }, [category, type, sort]);

  return (
    <main className="min-h-screen bg-[#f1ede4] text-[#261d18]">
      <section className="border-b border-[#c9beb2] px-6 py-16 text-center md:px-10 md:py-24">
        <p className="eyebrow">{category ? "House of Jaswanth" : "Collection 01 · Parampara"}</p>
        <h1 className="mt-5 font-display text-6xl font-light tracking-[-0.035em] md:text-8xl">{category ?? "The Collection"}</h1>
        <p className="mx-auto mt-6 max-w-xl text-sm leading-7 text-[#655850]">
          {category ? `Modern ${category.toLowerCase()}’s silhouettes, grounded in Indian textile traditions.` : "An exploration of inherited form, recut with clarity for the present."}
        </p>
      </section>

      <div className="sticky top-24 z-20 flex items-center justify-between border-b border-[#c9beb2] bg-[#f1ede4]/95 px-6 py-5 backdrop-blur md:px-10 lg:px-16">
        <button className="text-[10px] tracking-[0.18em] uppercase" onClick={() => setFiltersOpen((open) => !open)}>Filter {type !== "All" ? "· 1" : ""}</button>
        <p className="hidden text-[9px] tracking-[0.16em] text-[#766960] uppercase sm:block">{visible.length} pieces</p>
        <label className="text-[10px] tracking-[0.18em] uppercase">
          Sort
          <select className="ml-3 bg-transparent outline-none" onChange={(event) => setSort(event.target.value)} value={sort}>
            <option>Featured</option><option>Price, low to high</option><option>Price, high to low</option>
          </select>
        </label>
      </div>
      {filtersOpen && (
        <div className="flex flex-wrap gap-3 border-b border-[#c9beb2] px-6 py-5 md:px-10 lg:px-16">
          {types.map((item) => (
            <button className={`border px-5 py-3 text-[9px] tracking-[0.16em] uppercase ${type === item ? "border-[#2d1716] bg-[#2d1716] text-white" : "border-[#b7aba1]"}`} key={item} onClick={() => setType(item)}>{item}</button>
          ))}
        </div>
      )}
      <section className="grid gap-x-5 gap-y-14 px-4 py-12 sm:grid-cols-2 md:px-8 lg:grid-cols-4 lg:px-10 lg:py-16">
        {visible.map((product) => <ProductCard key={product.id} product={product} />)}
      </section>
    </main>
  );
}

export function ProductPage() {
  const { id } = useParams();
  const product = findProduct(id);
  const { addToBag, wishlist, toggleWishlist } = useStore();
  const [size, setSize] = useState("");
  const [notice, setNotice] = useState("");
  if (!product) return <div className="grid min-h-[60vh] place-items-center font-display text-4xl">Piece not found.</div>;
  const saved = wishlist.includes(product.id);
  const add = () => {
    if (!size) { setNotice("Please select a size."); return; }
    setNotice("");
    addToBag(product, size);
  };
  return (
    <main className="bg-[#f1ede4] text-[#261d18]">
      <div className="grid lg:grid-cols-[1.25fr_0.75fr]">
        <div className="grid gap-px bg-[#c9beb2] sm:grid-cols-2">
          {product.images.map((image, index) => <img alt={`${product.name}, view ${index + 1}`} className="aspect-[3/4] h-full w-full bg-[#ded4c5] object-cover" key={image} src={image} />)}
        </div>
        <aside className="h-fit px-6 py-12 md:px-12 lg:sticky lg:top-24 lg:px-16 lg:py-20">
          <p className="eyebrow">{product.category} · {product.type}</p>
          <div className="mt-5 flex items-start justify-between gap-6">
            <h1 className="font-display text-5xl leading-none md:text-6xl">{product.name}</h1>
            <button aria-label="Toggle wishlist" onClick={() => toggleWishlist(product.id)}><Heart filled={saved} /></button>
          </div>
          <p className="mt-5 text-sm">{formatPrice(product.price)}</p>
          <p className="mt-9 max-w-md text-sm leading-7 text-[#655850]">{product.description}</p>
          <div className="mt-10 border-t border-[#b8ada3] pt-8">
            <div className="mb-5 flex justify-between text-[10px] tracking-[0.17em] uppercase"><span>Select size</span><button className="underline">Size guide</button></div>
            <div className="grid grid-cols-5 gap-2">
              {product.sizes.map((item) => <button className={`border py-4 text-xs ${size === item ? "border-[#2d1716] bg-[#2d1716] text-white" : "border-[#b8ada3]"}`} key={item} onClick={() => { setSize(item); setNotice(""); }}>{item}</button>)}
            </div>
            {notice && <p className="mt-3 text-xs text-[#7f2f29]">{notice}</p>}
            <PrimaryButton className="mt-6" onClick={add}>Add to bag <Arrow /></PrimaryButton>
          </div>
          <div className="mt-8 divide-y divide-[#c9beb2] border-y border-[#c9beb2]">
            <details className="py-5"><summary className="cursor-pointer text-[10px] tracking-[0.18em] uppercase">Details & composition</summary><ul className="mt-5 space-y-2 text-xs leading-6 text-[#655850]">{product.details.map((detail) => <li key={detail}>— {detail}</li>)}</ul></details>
            <details className="py-5"><summary className="cursor-pointer text-[10px] tracking-[0.18em] uppercase">Delivery & returns</summary><p className="mt-5 text-xs leading-6 text-[#655850]">Complimentary delivery in India. International delivery and duties calculated at checkout. Returns accepted within 14 days.</p></details>
          </div>
          <Link className="group mt-8 flex items-center gap-4 text-[10px] tracking-[0.18em] uppercase" to="/appointment">Need personal guidance? Book an appointment <Arrow /></Link>
        </aside>
      </div>
      <section className="border-t border-[#c9beb2] px-6 py-20 md:px-10 lg:px-16">
        <p className="eyebrow">You may also consider</p>
        <div className="mt-9 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">{products.filter((item) => item.category === product.category && item.id !== product.id).slice(0, 4).map((item) => <ProductCard key={item.id} product={item} />)}</div>
      </section>
    </main>
  );
}

export function WishlistPage() {
  const { wishlist } = useStore();
  const saved = products.filter((product) => wishlist.includes(product.id));
  return (
    <main className="min-h-[70vh] bg-[#f1ede4] px-6 py-16 text-[#261d18] md:px-10 lg:px-16">
      <div className="mx-auto max-w-[1600px]">
        <p className="eyebrow">Your selection</p><h1 className="mt-5 font-display text-6xl md:text-8xl">Wishlist</h1>
        {saved.length ? <div className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">{saved.map((product) => <ProductCard key={product.id} product={product} />)}</div> : <div className="mt-16 border-t border-[#c9beb2] py-20 text-center"><p className="font-display text-4xl">Save pieces for later.</p><Link className="group mt-8 inline-flex items-center gap-4 border-b border-current pb-2 text-[10px] tracking-[0.18em] uppercase" to="/collections">Discover the collection <Arrow /></Link></div>}
      </div>
    </main>
  );
}
