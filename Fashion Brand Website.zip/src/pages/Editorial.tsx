import { Link } from "react-router";
import { Arrow, Field, PrimaryButton } from "../components/Layout";

const editorial = {
  about: {
    eyebrow: "The House",
    title: "An Indian point of view, expressed with quiet conviction.",
    intro:
      "House of Jaswanth is a contemporary luxury label founded on the belief that heritage is not static—it is a living language.",
    image: "https://images.unsplash.com/photo-1761940546803-ad87f8155b6a?auto=format&fit=crop&w=1600&q=88",
    secondImage: "https://images.unsplash.com/photo-1680506742319-b44ad1c534e0?auto=format&fit=crop&w=1200&q=88",
  },
  craftsmanship: {
    eyebrow: "Craftsmanship",
    title: "Made by many hands. Designed to endure.",
    intro:
      "Every garment begins with material and maker. We work slowly, preserving the marks of the hand while refining each silhouette for the present.",
    image: "https://images.unsplash.com/photo-1640292343595-889db1c8262e?auto=format&fit=crop&w=1600&q=88",
    secondImage: "https://images.unsplash.com/photo-1561060511-dc6d28b71f8b?auto=format&fit=crop&w=1200&q=88",
  },
};

export function EditorialPage({ page }: { page: "about" | "craftsmanship" }) {
  const content = editorial[page];
  return (
    <main className="bg-[#f1ede4] text-[#261d18]">
      <section className="grid lg:grid-cols-2">
        <div className="flex flex-col justify-center px-6 py-20 md:px-16 lg:px-[8vw]">
          <p className="eyebrow">{content.eyebrow}</p>
          <h1 className="mt-8 font-display text-[clamp(3.5rem,6vw,7rem)] font-light leading-[0.92] tracking-[-0.04em]">{content.title}</h1>
          <p className="mt-10 max-w-lg text-sm leading-7 text-[#655850]">{content.intro}</p>
        </div>
        <img alt="" className="min-h-[560px] h-full w-full object-cover lg:min-h-[760px]" src={content.image} />
      </section>
      <section className="mx-auto grid max-w-[1500px] gap-16 px-6 py-24 md:px-10 md:py-36 lg:grid-cols-[0.8fr_1.2fr] lg:px-16">
        <p className="eyebrow">{page === "about" ? "Our philosophy" : "The process"}</p>
        <div>
          <h2 className="font-display text-4xl leading-tight md:text-6xl">
            {page === "about"
              ? "We create for a wardrobe beyond seasons—pieces with presence, purpose, and permanence."
              : "Technique is never ornament alone. It is structure, memory, and the unmistakable character of the human hand."}
          </h2>
          <div className="mt-12 grid gap-8 border-t border-[#c9beb2] pt-8 text-sm leading-7 text-[#655850] sm:grid-cols-2">
            <p>{page === "about" ? "Our collections draw from India’s vast textile vocabulary without nostalgia. Proportion is clarified, decoration is distilled, and familiar forms are allowed to become new." : "From handloom weaving to fine zari and tonal embroidery, our techniques are chosen for what they bring to a garment: depth, texture, and a life that develops through wear."}</p>
            <p>{page === "about" ? "Designed in New Delhi and made in close collaboration with skilled ateliers, every piece reflects a shared pursuit of beauty through restraint." : "We produce in considered quantities and work closely with our partners, respecting both the time of the maker and the natural pace of exceptional work."}</p>
          </div>
        </div>
      </section>
      <section className="grid bg-[#2d1716] text-white lg:grid-cols-2">
        <img alt="" className="h-[560px] w-full object-cover opacity-90 lg:h-[760px]" src={content.secondImage} />
        <div className="flex flex-col justify-center px-6 py-20 md:px-16 lg:px-[8vw]">
          <p className="eyebrow !text-[#c9b6a3]">{page === "about" ? "The beginning" : "A living archive"}</p>
          <h2 className="mt-8 font-display text-5xl leading-none md:text-7xl">{page === "about" ? "A house shaped in India." : "Tradition, carried forward."}</h2>
          <p className="mt-8 max-w-md text-sm leading-7 text-white/65">We believe luxury is found in intimacy: knowing where something comes from, understanding how it was made, and choosing to keep it for years.</p>
          <Link className="group mt-9 flex w-fit items-center gap-4 border-b border-white pb-2 text-[10px] tracking-[0.18em] uppercase" to={page === "about" ? "/craftsmanship" : "/collections"}>{page === "about" ? "Discover our craft" : "Explore the collection"} <Arrow /></Link>
        </div>
      </section>
    </main>
  );
}

export function ContactPage() {
  return (
    <main className="min-h-screen bg-[#f1ede4] text-[#261d18]">
      <section className="mx-auto grid max-w-[1500px] gap-16 px-6 py-20 md:px-10 lg:grid-cols-[0.8fr_1.2fr] lg:px-16 lg:py-28">
        <div><p className="eyebrow">Client services</p><h1 className="mt-6 font-display text-6xl md:text-8xl">How may we assist?</h1><p className="mt-7 max-w-md text-sm leading-7 text-[#655850]">Our client advisors are available Monday to Saturday, 10:00–18:00 IST.</p>
          <div className="mt-12 space-y-8 border-t border-[#c9beb2] pt-8 text-sm"><div><p className="eyebrow">Email</p><a className="mt-2 block" href="mailto:care@houseofjaswanth.com">care@houseofjaswanth.com</a></div><div><p className="eyebrow">Telephone</p><a className="mt-2 block" href="tel:+911141001844">+91 11 4100 1844</a></div><div><p className="eyebrow">New Delhi studio</p><p className="mt-2 leading-6">By private appointment only</p></div></div>
        </div>
        <form className="grid gap-7 self-start bg-[#e4dccf] p-7 md:grid-cols-2 md:p-12" onSubmit={(event) => event.preventDefault()}><Field label="First name" required /><Field label="Last name" required /><Field label="Email address" type="email" required /><Field label="Phone number" type="tel" /><label className="md:col-span-2 text-[10px] tracking-[0.18em] uppercase">Subject<select className="mt-3 w-full border-b border-[#9f9288] bg-transparent py-3 text-sm tracking-normal outline-none"><option>Product enquiry</option><option>Order support</option><option>Press and partnerships</option><option>Other</option></select></label><label className="md:col-span-2 text-[10px] tracking-[0.18em] uppercase">Message<textarea className="mt-3 h-28 w-full resize-none border-b border-[#9f9288] bg-transparent py-3 text-sm tracking-normal outline-none" required /></label><div className="md:col-span-2"><PrimaryButton type="submit">Send enquiry <Arrow /></PrimaryButton></div></form>
      </section>
    </main>
  );
}

const policies = {
  shipping: {
    eyebrow: "Client services",
    title: "Shipping & Returns",
    sections: [
      ["Delivery", "Complimentary standard delivery is available on all orders within India. Orders are prepared within 1–2 working days and typically arrive within 3–5 working days. Express delivery is available at checkout."],
      ["International orders", "International shipping rates and estimated delivery times are calculated at checkout. Duties and taxes are shown where possible; any local charges remain the responsibility of the recipient."],
      ["Returns", "Unworn, unaltered pieces with original tags may be returned within 14 days of delivery. Made-to-measure, personalised, and final-sale pieces cannot be returned."],
      ["Exchanges", "Size exchanges are subject to availability. Contact Client Services within 14 days and we will arrange the exchange or offer a return."],
    ],
  },
  privacy: {
    eyebrow: "Legal",
    title: "Privacy Policy",
    sections: [
      ["Information we collect", "We collect information you provide when placing an order, creating an account, booking an appointment, or contacting the House, along with limited technical data needed to operate our services."],
      ["How we use information", "Your information is used to fulfil orders, provide client services, improve our platform, prevent fraud, and—with your permission—share House news and invitations."],
      ["Sharing and retention", "We share only the information required by trusted payment, delivery, and technology partners. We retain data only for as long as required for service and legal purposes."],
      ["Your choices", "You may request access, correction, or deletion of your personal information and may withdraw marketing consent at any time by contacting our Client Services team."],
    ],
  },
  terms: {
    eyebrow: "Legal",
    title: "Terms & Conditions",
    sections: [
      ["Use of this site", "By using this site, you agree to these terms and all applicable laws. Content is provided for personal, non-commercial use and remains the property of House of Jaswanth."],
      ["Orders", "All orders are subject to availability and acceptance. We may decline or cancel an order in the event of a pricing error, suspected fraud, or inability to fulfil the order."],
      ["Product representation", "We take care to present colours, materials, and dimensions accurately. Natural variations and the character of handwork are intrinsic to each piece and are not defects."],
      ["Governing law", "These terms are governed by the laws of India. Any dispute will be subject to the exclusive jurisdiction of the courts of New Delhi."],
    ],
  },
};

export function PolicyPage({ page }: { page: keyof typeof policies }) {
  const content = policies[page];
  return (
    <main className="min-h-screen bg-[#f1ede4] px-6 py-20 text-[#261d18] md:px-10 lg:px-16">
      <div className="mx-auto max-w-5xl">
        <p className="eyebrow">{content.eyebrow}</p><h1 className="mt-5 font-display text-6xl md:text-8xl">{content.title}</h1><p className="mt-6 text-[10px] tracking-[0.15em] text-[#766960] uppercase">Last updated · 10 October 2025</p>
        <div className="mt-14 divide-y divide-[#c9beb2] border-t border-[#c9beb2]">{content.sections.map(([title, copy], index) => <section className="grid gap-6 py-9 md:grid-cols-[80px_240px_1fr]" key={title}><span className="font-display text-2xl">{String(index + 1).padStart(2, "0")}</span><h2 className="font-display text-2xl">{title}</h2><p className="text-sm leading-7 text-[#655850]">{copy}</p></section>)}</div>
        <p className="mt-10 text-sm">For further assistance, please <Link className="underline" to="/contact">contact Client Services</Link>.</p>
      </div>
    </main>
  );
}

export function NotFound() {
  return <main className="grid min-h-[70vh] place-items-center bg-[#ded4c5] px-6 text-center text-[#261d18]"><div><p className="eyebrow">404</p><h1 className="mt-6 font-display text-6xl md:text-8xl">This page has moved.</h1><Link className="group mt-9 inline-flex items-center gap-4 border-b border-current pb-2 text-[10px] tracking-[0.18em] uppercase" to="/">Return to the house <Arrow /></Link></div></main>;
}
