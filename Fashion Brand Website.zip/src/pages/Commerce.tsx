import { useState, type FormEvent } from "react";
import { Link, useNavigate } from "react-router";
import { Arrow, Field, PrimaryButton } from "../components/Layout";
import { formatPrice, products } from "../data/products";
import { useStore } from "../app/store";

const Stepper = ({ current, steps }: { current: number; steps: string[] }) => (
  <div className="flex border-y border-[#c9beb2]">
    {steps.map((step, index) => (
      <div className={`flex-1 px-2 py-4 text-center text-[8px] tracking-[0.14em] uppercase md:text-[10px] ${index === current ? "bg-[#2d1716] text-white" : "text-[#766960]"}`} key={step}>
        <span className="mr-2">{String(index + 1).padStart(2, "0")}</span>{step}
      </div>
    ))}
  </div>
);

export function CheckoutPage() {
  const { bag } = useStore();
  const navigate = useNavigate();
  const [step, setStep] = useState(0);
  const [shipping, setShipping] = useState("standard");
  const subtotal = bag.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  const shippingCost = shipping === "express" ? 1800 : 0;
  const submit = (event: FormEvent) => {
    event.preventDefault();
    if (step < 2) setStep((current) => current + 1);
    else navigate("/order-confirmation");
    window.scrollTo({ top: 0, behavior: "smooth" });
  };
  if (!bag.length) {
    return <main className="grid min-h-[65vh] place-items-center bg-[#f1ede4] px-6 text-center"><div><h1 className="font-display text-5xl">Your bag is empty.</h1><Link className="mt-8 inline-block border-b border-current pb-2 text-[10px] tracking-[0.18em] uppercase" to="/collections">Return to collection</Link></div></main>;
  }
  return (
    <main className="min-h-screen bg-[#f1ede4] text-[#261d18]">
      <div className="mx-auto max-w-[1500px] px-6 py-12 md:px-10 lg:px-16">
        <div className="mb-10 flex items-end justify-between">
          <div><p className="eyebrow">Secure checkout</p><h1 className="mt-4 font-display text-5xl md:text-7xl">Complete your order</h1></div>
          <Link className="hidden text-[10px] tracking-[0.18em] uppercase md:block" to="/collections">Continue shopping</Link>
        </div>
        <Stepper current={step} steps={["Delivery", "Payment", "Review"]} />
        <div className="grid gap-14 py-12 lg:grid-cols-[1fr_420px]">
          <form key={step} onSubmit={submit}>
            {step === 0 && (
              <div className="animate-rise">
                <h2 className="font-display text-3xl">Delivery details</h2>
                <div className="mt-9 grid gap-x-8 gap-y-7 sm:grid-cols-2">
                  <Field label="First name" required /><Field label="Last name" required />
                  <Field label="Email address" type="email" required /><Field label="Phone number" type="tel" required />
                  <div className="sm:col-span-2"><Field label="Address" required /></div>
                  <Field label="City" required /><Field label="Postal code" required />
                  <Field label="State" required /><Field label="Country" required />
                </div>
                <div className="mt-12">
                  <p className="text-[10px] tracking-[0.18em] uppercase">Shipping method</p>
                  <label className="mt-4 flex cursor-pointer items-center justify-between border border-[#b8ada3] p-5"><span><input checked={shipping === "standard"} className="mr-4" name="shipping" onChange={() => setShipping("standard")} type="radio" />Standard delivery <small className="ml-2 text-[#766960]">3–5 working days</small></span><span className="text-xs">Complimentary</span></label>
                  <label className="mt-3 flex cursor-pointer items-center justify-between border border-[#b8ada3] p-5"><span><input checked={shipping === "express"} className="mr-4" name="shipping" onChange={() => setShipping("express")} type="radio" />Express delivery <small className="ml-2 text-[#766960]">1–2 working days</small></span><span className="text-xs">{formatPrice(1800)}</span></label>
                </div>
              </div>
            )}
            {step === 1 && (
              <div className="animate-rise">
                <h2 className="font-display text-3xl">Payment</h2>
                <p className="mt-3 text-xs leading-6 text-[#766960]">All transactions are encrypted and secure.</p>
                <div className="mt-9 border border-[#2d1716] p-6">
                  <div className="flex justify-between"><p className="text-[10px] tracking-[0.18em] uppercase">Credit or debit card</p><p className="text-[10px] tracking-[0.1em]">VISA · MC · AMEX</p></div>
                  <div className="mt-8 grid gap-x-8 gap-y-7 sm:grid-cols-2">
                    <div className="sm:col-span-2"><Field label="Card number" placeholder="0000 0000 0000 0000" required /></div>
                    <Field label="Expiry date" placeholder="MM / YY" required /><Field label="Security code" placeholder="CVV" required />
                    <div className="sm:col-span-2"><Field label="Name on card" required /></div>
                  </div>
                </div>
                <div className="mt-4 grid gap-3 sm:grid-cols-2">
                  <button className="border border-[#b8ada3] p-5 text-left text-[10px] tracking-[0.16em] uppercase" type="button">UPI</button>
                  <button className="border border-[#b8ada3] p-5 text-left text-[10px] tracking-[0.16em] uppercase" type="button">Net banking</button>
                </div>
              </div>
            )}
            {step === 2 && (
              <div className="animate-rise">
                <h2 className="font-display text-3xl">Review your order</h2>
                <div className="mt-8 divide-y divide-[#c9beb2] border-y border-[#c9beb2]">
                  <div className="grid gap-3 py-6 sm:grid-cols-[180px_1fr]"><p className="eyebrow">Deliver to</p><p className="text-sm leading-6">Ananya Rao<br />18 Lodhi Road, New Delhi 110003<br />India</p></div>
                  <div className="grid gap-3 py-6 sm:grid-cols-[180px_1fr]"><p className="eyebrow">Shipping</p><p className="text-sm">{shipping === "express" ? "Express · 1–2 working days" : "Standard · 3–5 working days"}</p></div>
                  <div className="grid gap-3 py-6 sm:grid-cols-[180px_1fr]"><p className="eyebrow">Payment</p><p className="text-sm">Card ending in 4242</p></div>
                </div>
                <label className="mt-7 flex items-start gap-3 text-xs leading-5"><input className="mt-1" required type="checkbox" />I agree to the Terms of Sale and acknowledge the Privacy Policy.</label>
              </div>
            )}
            <div className="mt-10 flex items-center gap-4">
              {step > 0 && <button className="min-h-14 border border-[#8f8278] px-8 text-[10px] tracking-[0.18em] uppercase" onClick={() => setStep((current) => current - 1)} type="button">Back</button>}
              <PrimaryButton type="submit">{step === 2 ? `Pay ${formatPrice(subtotal + shippingCost)}` : "Continue"} <Arrow /></PrimaryButton>
            </div>
          </form>
          <aside className="h-fit bg-[#e4dccf] p-6 md:p-8 lg:sticky lg:top-32">
            <p className="eyebrow">Order summary · {bag.length} pieces</p>
            <div className="mt-6 divide-y divide-[#c3b7ab]">
              {bag.map((item) => (
                <div className="grid grid-cols-[80px_1fr_auto] gap-4 py-5" key={item.product.id}>
                  <img alt="" className="h-24 w-20 object-cover" src={item.product.images[0]} />
                  <div><p className="font-display text-lg">{item.product.name}</p><p className="mt-2 text-[9px] tracking-[0.13em] uppercase">Size {item.size} · Qty {item.quantity}</p></div>
                  <p className="text-[10px]">{formatPrice(item.product.price * item.quantity)}</p>
                </div>
              ))}
            </div>
            <div className="space-y-4 border-t border-[#a99d91] pt-6 text-xs"><div className="flex justify-between"><span>Subtotal</span><span>{formatPrice(subtotal)}</span></div><div className="flex justify-between"><span>Shipping</span><span>{shippingCost ? formatPrice(shippingCost) : "Complimentary"}</span></div><div className="flex justify-between border-t border-[#a99d91] pt-5 font-display text-xl"><span>Total</span><span>{formatPrice(subtotal + shippingCost)}</span></div></div>
          </aside>
        </div>
      </div>
    </main>
  );
}

export function OrderConfirmation() {
  return (
    <main className="min-h-[75vh] bg-[#ded4c5] px-6 py-20 text-center text-[#261d18] md:py-28">
      <p className="eyebrow">Order HOJ–250184</p>
      <h1 className="mx-auto mt-8 max-w-3xl font-display text-6xl leading-[0.95] md:text-8xl">Thank you. Your order is confirmed.</h1>
      <p className="mx-auto mt-8 max-w-lg text-sm leading-7 text-[#655850]">A confirmation has been sent to your email. Your pieces will be prepared with care and dispatched within two working days.</p>
      <div className="mx-auto mt-12 grid max-w-2xl gap-px bg-[#b7aa9e] text-left sm:grid-cols-2">
        <div className="bg-[#f1ede4] p-7"><p className="eyebrow">Delivery</p><p className="mt-4 text-sm leading-6">Estimated arrival<br />14–16 October 2025</p></div>
        <div className="bg-[#f1ede4] p-7"><p className="eyebrow">Updates</p><p className="mt-4 text-sm leading-6">Tracking will be shared<br />once your order ships.</p></div>
      </div>
      <div className="mt-12 flex flex-wrap justify-center gap-6"><Link className="border-b border-current pb-2 text-[10px] tracking-[0.18em] uppercase" to="/account">View order</Link><Link className="border-b border-current pb-2 text-[10px] tracking-[0.18em] uppercase" to="/collections">Continue exploring</Link></div>
    </main>
  );
}

export function AccountPage() {
  const [signedIn, setSignedIn] = useState(false);
  const [tab, setTab] = useState("Orders");
  if (!signedIn) return (
    <main className="min-h-[70vh] bg-[#f1ede4] px-6 py-20 text-[#261d18]">
      <div className="mx-auto max-w-md"><p className="eyebrow">Client account</p><h1 className="mt-5 font-display text-6xl">Welcome back.</h1><p className="mt-5 text-sm leading-7 text-[#655850]">Access your orders, saved pieces, addresses, and appointments.</p>
        <form className="mt-10 space-y-7" onSubmit={(event) => { event.preventDefault(); setSignedIn(true); }}><Field label="Email address" type="email" required /><Field label="Password" type="password" required /><PrimaryButton type="submit">Sign in <Arrow /></PrimaryButton></form>
        <button className="mt-5 text-[9px] tracking-[0.16em] uppercase underline">Forgot password?</button>
        <p className="mt-10 border-t border-[#c9beb2] pt-7 text-xs">New to the House? <button className="ml-2 uppercase underline" onClick={() => setSignedIn(true)}>Create an account</button></p>
      </div>
    </main>
  );
  return (
    <main className="min-h-[70vh] bg-[#f1ede4] px-6 py-16 text-[#261d18] md:px-10 lg:px-16">
      <div className="mx-auto max-w-[1400px]"><p className="eyebrow">Your account</p><h1 className="mt-5 font-display text-6xl md:text-8xl">Good afternoon, Ananya.</h1>
        <div className="mt-12 grid gap-10 lg:grid-cols-[240px_1fr]">
          <nav className="flex gap-6 overflow-x-auto border-b border-[#c9beb2] lg:block lg:border-b-0">{["Orders", "Wishlist", "Addresses", "Details"].map((item) => <button className={`block whitespace-nowrap border-b py-4 text-[10px] tracking-[0.18em] uppercase lg:w-full lg:text-left ${tab === item ? "border-[#2d1716]" : "border-transparent"}`} key={item} onClick={() => setTab(item)}>{item}</button>)}</nav>
          <section className="border-t border-[#c9beb2] pt-7">
            <h2 className="font-display text-3xl">{tab}</h2>
            {tab === "Orders" && <div className="mt-8 border border-[#b8ada3] p-6"><div className="flex flex-wrap justify-between gap-4"><div><p className="eyebrow">HOJ–250184 · Confirmed</p><p className="mt-3 text-sm">Placed 10 October 2025</p></div><p className="font-display text-xl">{formatPrice(38500)}</p></div><div className="mt-6 flex items-center gap-5 border-t border-[#c9beb2] pt-6"><img alt="" className="h-28 w-24 object-cover" src={products[0].images[0]} /><div><p className="font-display text-xl">{products[0].name}</p><p className="mt-2 text-[9px] tracking-[0.15em] uppercase">Size S · Indigo</p><button className="mt-5 text-[9px] tracking-[0.15em] uppercase underline">Track order</button></div></div></div>}
            {tab === "Wishlist" && <p className="mt-8 text-sm">Your saved pieces are available in your <Link className="underline" to="/wishlist">wishlist</Link>.</p>}
            {tab === "Addresses" && <div className="mt-8 max-w-md border border-[#b8ada3] p-6 text-sm leading-7"><p className="eyebrow">Default</p><p className="mt-4">Ananya Rao<br />18 Lodhi Road<br />New Delhi 110003<br />India</p><button className="mt-5 text-[9px] tracking-[0.15em] uppercase underline">Edit address</button></div>}
            {tab === "Details" && <div className="mt-8 grid max-w-2xl gap-7 sm:grid-cols-2"><Field label="First name" placeholder="Ananya" /><Field label="Last name" placeholder="Rao" /><Field label="Email" placeholder="ananya@example.com" /><Field label="Phone" placeholder="+91 98765 43210" /></div>}
          </section>
        </div>
      </div>
    </main>
  );
}

export function AppointmentPage() {
  const [step, setStep] = useState(0);
  const [date, setDate] = useState("");
  const [time, setTime] = useState("");
  const dates = ["Tue 14 Oct", "Wed 15 Oct", "Thu 16 Oct", "Fri 17 Oct", "Sat 18 Oct"];
  const times = ["10:30 AM", "12:00 PM", "2:30 PM", "4:00 PM", "5:30 PM"];
  return (
    <main className="min-h-screen bg-[#ded4c5] text-[#261d18]">
      <section className="grid min-h-[76vh] lg:grid-cols-[0.8fr_1.2fr]">
        <div className="relative min-h-[430px] overflow-hidden bg-[#2d1716]">
          <img alt="Private virtual fashion consultation" className="absolute inset-0 h-full w-full object-cover opacity-75" src="https://images.unsplash.com/photo-1737448859179-b5438e08514d?auto=format&fit=crop&w=1200&q=88" />
          <div className="absolute inset-0 bg-gradient-to-t from-[#2d1716]/80 to-transparent" />
          <div className="absolute inset-x-0 bottom-0 p-8 text-white md:p-12"><p className="eyebrow !text-white/60">Private client service</p><h1 className="mt-5 font-display text-5xl leading-none md:text-7xl">A moment, entirely yours.</h1><p className="mt-6 max-w-md text-sm leading-7 text-white/75">Meet a House stylist virtually for a personal introduction to the collection, fit guidance, and considered wardrobe advice.</p></div>
        </div>
        <div className="flex flex-col justify-center px-6 py-14 md:px-14 lg:px-20">
          <Stepper current={Math.min(step, 3)} steps={["Service", "Date & time", "Details", "Confirmation"]} />
          <div className="mx-auto mt-12 w-full max-w-2xl">
            {step === 0 && <div className="animate-rise"><p className="eyebrow">Select a service</p><h2 className="mt-4 font-display text-4xl">Virtual Consultation</h2><button className="mt-8 w-full border border-[#2d1716] bg-[#f1ede4] p-6 text-left" onClick={() => setStep(1)}><span className="flex justify-between"><span className="font-display text-2xl">Collection & Styling</span><span className="text-xs">45 min</span></span><span className="mt-4 block text-xs leading-6 text-[#655850]">A private video appointment with one of our House stylists.</span></button></div>}
            {step === 1 && <div className="animate-rise"><p className="eyebrow">Choose your appointment</p><h2 className="mt-4 font-display text-4xl">Date & time</h2><p className="mt-3 text-xs text-[#655850]">Times shown in Indian Standard Time (IST).</p><div className="mt-8 grid grid-cols-2 gap-2 sm:grid-cols-5">{dates.map((item) => <button className={`border px-3 py-4 text-xs ${date === item ? "bg-[#2d1716] text-white" : "border-[#a99d91]"}`} key={item} onClick={() => setDate(item)}>{item}</button>)}</div><div className="mt-5 grid grid-cols-2 gap-2 sm:grid-cols-3">{times.map((item) => <button className={`border px-3 py-4 text-xs ${time === item ? "bg-[#2d1716] text-white" : "border-[#a99d91]"}`} key={item} onClick={() => setTime(item)}>{item}</button>)}</div><PrimaryButton className="mt-8" disabled={!date || !time} onClick={() => setStep(2)}>Continue <Arrow /></PrimaryButton></div>}
            {step === 2 && <form className="animate-rise" onSubmit={(event) => { event.preventDefault(); setStep(3); }}><p className="eyebrow">Tell us about yourself</p><h2 className="mt-4 font-display text-4xl">Your details</h2><div className="mt-8 grid gap-7 sm:grid-cols-2"><Field label="First name" required /><Field label="Last name" required /><Field label="Email address" type="email" required /><Field label="Phone number" type="tel" required /></div><label className="mt-7 block text-[10px] tracking-[0.18em] uppercase">How may we assist?<textarea className="mt-3 h-24 w-full resize-none border border-[#a99d91] bg-transparent p-4 text-sm tracking-normal outline-none" placeholder="Pieces, sizing, or occasion details" /></label><PrimaryButton className="mt-8" type="submit">Confirm appointment <Arrow /></PrimaryButton></form>}
            {step === 3 && <div className="animate-rise text-center"><p className="eyebrow">Appointment confirmed</p><h2 className="mt-6 font-display text-5xl md:text-6xl">We look forward to meeting you.</h2><p className="mx-auto mt-7 max-w-md text-sm leading-7 text-[#655850]">Your virtual consultation is confirmed for <strong>{date} at {time} IST</strong>. A private video link has been sent to your email.</p><div className="mt-9 flex justify-center gap-6"><button className="border-b border-current pb-2 text-[9px] tracking-[0.16em] uppercase">Add to calendar</button><Link className="border-b border-current pb-2 text-[9px] tracking-[0.16em] uppercase" to="/">Return home</Link></div></div>}
          </div>
        </div>
      </section>
    </main>
  );
}
