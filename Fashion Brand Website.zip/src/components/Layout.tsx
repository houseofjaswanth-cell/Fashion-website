import { useEffect, useState, type ReactNode } from "react";
import { Link, NavLink, Outlet, useLocation } from "react-router";
import { formatPrice, products } from "../data/products";
import { useStore } from "../app/store";

export const Arrow = () => (
  <svg aria-hidden="true" className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" fill="none" viewBox="0 0 24 24">
    <path d="M5 12h14M14 7l5 5-5 5" stroke="currentColor" strokeLinecap="round" />
  </svg>
);

export const Close = () => (
  <svg aria-hidden="true" className="h-5 w-5" fill="none" viewBox="0 0 24 24">
    <path d="m6 6 12 12M18 6 6 18" stroke="currentColor" strokeLinecap="round" />
  </svg>
);

export const Heart = ({ filled = false }: { filled?: boolean }) => (
  <svg aria-hidden="true" className="h-5 w-5" fill={filled ? "currentColor" : "none"} viewBox="0 0 24 24">
    <path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1.1-1.1a5.5 5.5 0 0 0-7.8 7.8l1.1 1.1L12 21l7.8-7.5 1.1-1.1a5.5 5.5 0 0 0-.1-7.8Z" stroke="currentColor" strokeWidth="1.2" />
  </svg>
);

export function Logo({ light = false }: { light?: boolean }) {
  return (
    <Link className={`font-display text-center text-[18px] font-semibold leading-[0.82] tracking-[0.16em] uppercase md:text-[21px] ${light ? "text-white" : ""}`} to="/">
      House of
      <span className="mt-2 block text-[0.72em] tracking-[0.38em]">Jaswanth</span>
    </Link>
  );
}

export function PrimaryButton({
  children,
  onClick,
  type = "button",
  disabled = false,
  className = "",
}: {
  children: ReactNode;
  onClick?: () => void;
  type?: "button" | "submit";
  disabled?: boolean;
  className?: string;
}) {
  return (
    <button
      className={`group flex min-h-14 w-full items-center justify-center gap-4 bg-[#2d1716] px-6 text-[10px] tracking-[0.22em] text-white uppercase transition hover:bg-[#4c2824] disabled:cursor-not-allowed disabled:opacity-40 ${className}`}
      disabled={disabled}
      onClick={onClick}
      type={type}
    >
      {children}
    </button>
  );
}

export function Field({
  label,
  type = "text",
  placeholder = "",
  required = false,
}: {
  label: string;
  type?: string;
  placeholder?: string;
  required?: boolean;
}) {
  const id = label.toLowerCase().replaceAll(" ", "-");
  return (
    <label className="block text-[10px] tracking-[0.18em] uppercase" htmlFor={id}>
      {label}
      <input
        className="mt-3 w-full border-b border-[#9f9288] bg-transparent py-3 text-sm tracking-normal outline-none transition focus:border-[#2d1716]"
        id={id}
        placeholder={placeholder}
        required={required}
        type={type}
      />
    </label>
  );
}

function SearchDrawer() {
  const { searchOpen, setSearchOpen } = useStore();
  const [query, setQuery] = useState("");
  const matches = products.filter((product) =>
    `${product.name} ${product.type} ${product.color}`.toLowerCase().includes(query.toLowerCase()),
  );
  if (!searchOpen) return null;
  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/35" role="dialog" aria-modal="true" aria-label="Search">
      <button className="h-full flex-1 cursor-default" onClick={() => setSearchOpen(false)} aria-label="Close search" />
      <aside className="h-full w-full max-w-xl overflow-y-auto bg-[#f1ede4] p-6 shadow-2xl md:p-10">
        <div className="flex items-center justify-between">
          <p className="eyebrow">Search the house</p>
          <button onClick={() => setSearchOpen(false)} aria-label="Close"><Close /></button>
        </div>
        <input
          autoFocus
          className="mt-14 w-full border-b border-[#776a61] bg-transparent pb-4 font-display text-4xl outline-none placeholder:text-[#8e8178]"
          onChange={(event) => setQuery(event.target.value)}
          placeholder="What are you looking for?"
          value={query}
        />
        <div className="mt-10 space-y-5">
          {(query ? matches : products.slice(0, 3)).map((product) => (
            <Link className="grid grid-cols-[80px_1fr_auto] items-center gap-5 border-b border-[#c8beb3] pb-5" key={product.id} onClick={() => setSearchOpen(false)} to={`/product/${product.id}`}>
              <img alt="" className="h-24 w-20 object-cover" src={product.images[0]} />
              <div>
                <p className="font-display text-xl">{product.name}</p>
                <p className="mt-1 text-[10px] tracking-[0.15em] text-[#766960] uppercase">{product.category} · {product.color}</p>
              </div>
              <p className="text-xs">{formatPrice(product.price)}</p>
            </Link>
          ))}
          {query && !matches.length && <p className="py-10 text-sm text-[#766960]">No pieces found. Try another term.</p>}
        </div>
      </aside>
    </div>
  );
}

function BagDrawer() {
  const { bag, bagOpen, setBagOpen, updateQuantity, removeFromBag } = useStore();
  const total = bag.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  if (!bagOpen) return null;
  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/35" role="dialog" aria-modal="true" aria-label="Shopping bag">
      <button className="h-full flex-1 cursor-default" onClick={() => setBagOpen(false)} aria-label="Close bag" />
      <aside className="flex h-full w-full max-w-lg flex-col bg-[#f1ede4] shadow-2xl">
        <div className="flex items-center justify-between border-b border-[#c8beb3] p-6 md:p-8">
          <p className="eyebrow">Your bag · {bag.reduce((sum, item) => sum + item.quantity, 0)}</p>
          <button onClick={() => setBagOpen(false)} aria-label="Close"><Close /></button>
        </div>
        <div className="flex-1 overflow-y-auto p-6 md:p-8">
          {!bag.length && (
            <div className="flex h-full flex-col items-center justify-center text-center">
              <p className="font-display text-4xl">Your bag is empty.</p>
              <Link className="mt-8 border-b border-current pb-2 text-[10px] tracking-[0.2em] uppercase" onClick={() => setBagOpen(false)} to="/collections">Explore the collection</Link>
            </div>
          )}
          {bag.map((item) => (
            <article className="grid grid-cols-[110px_1fr] gap-5 border-b border-[#c8beb3] py-6 first:pt-0" key={`${item.product.id}-${item.size}`}>
              <img alt="" className="h-36 w-full object-cover" src={item.product.images[0]} />
              <div className="flex flex-col justify-between">
                <div>
                  <div className="flex justify-between gap-4">
                    <p className="font-display text-xl">{item.product.name}</p>
                    <p className="text-xs">{formatPrice(item.product.price)}</p>
                  </div>
                  <p className="mt-2 text-[10px] tracking-[0.15em] text-[#766960] uppercase">Size {item.size} · {item.product.color}</p>
                </div>
                <div className="flex items-end justify-between">
                  <div className="flex items-center gap-4 border border-[#b6aaa0] px-3 py-2 text-xs">
                    <button onClick={() => updateQuantity(item.product.id, item.quantity - 1)}>−</button>
                    <span>{item.quantity}</span>
                    <button onClick={() => updateQuantity(item.product.id, item.quantity + 1)}>+</button>
                  </div>
                  <button className="text-[9px] tracking-[0.15em] uppercase underline" onClick={() => removeFromBag(item.product.id)}>Remove</button>
                </div>
              </div>
            </article>
          ))}
        </div>
        {!!bag.length && (
          <div className="border-t border-[#c8beb3] p-6 md:p-8">
            <div className="mb-6 flex justify-between font-display text-xl">
              <span>Subtotal</span><span>{formatPrice(total)}</span>
            </div>
            <p className="mb-6 text-[10px] text-[#766960]">Shipping and taxes calculated at checkout.</p>
            <Link onClick={() => setBagOpen(false)} to="/checkout"><PrimaryButton>Proceed to checkout <Arrow /></PrimaryButton></Link>
          </div>
        )}
      </aside>
    </div>
  );
}

export function SiteHeader() {
  const [menuOpen, setMenuOpen] = useState(false);
  const { bag, wishlist, setBagOpen, setSearchOpen } = useStore();
  const location = useLocation();
  useEffect(() => setMenuOpen(false), [location.pathname]);
  return (
    <header className="sticky top-0 z-40 border-b border-[#c9beb2] bg-[#f1ede4]/95 text-[#261d18] backdrop-blur-md">
      <div className="mx-auto flex h-24 max-w-[1600px] items-center justify-between px-6 md:px-10 lg:px-16">
        <button className="flex h-10 w-10 flex-col items-center justify-center gap-1.5 lg:hidden" onClick={() => setMenuOpen((open) => !open)} aria-label="Menu">
          <span className="h-px w-5 bg-current" /><span className="h-px w-5 bg-current" />
        </button>
        <nav className="hidden items-center gap-8 text-[10px] tracking-[0.18em] uppercase lg:flex">
          <NavLink className="nav-link" to="/collections">Collections</NavLink>
          <NavLink className="nav-link" to="/women">Women</NavLink>
          <NavLink className="nav-link" to="/men">Men</NavLink>
        </nav>
        <div className="absolute left-1/2 -translate-x-1/2"><Logo /></div>
        <div className="flex items-center gap-4 text-[10px] tracking-[0.16em] uppercase md:gap-6">
          <button className="nav-link hidden sm:block" onClick={() => setSearchOpen(true)}>Search</button>
          <Link className="nav-link hidden md:block" to="/appointment">Appointment</Link>
          <Link className="nav-link hidden sm:block" to="/account">Account</Link>
          <Link className="relative" to="/wishlist" aria-label={`Wishlist with ${wishlist.length} items`}><Heart filled={wishlist.length > 0} /></Link>
          <button onClick={() => setBagOpen(true)}>Bag ({bag.reduce((sum, item) => sum + item.quantity, 0)})</button>
        </div>
      </div>
      {menuOpen && (
        <nav className="border-t border-[#c9beb2] px-6 py-8 lg:hidden">
          {[
            ["Collections", "/collections"], ["Women", "/women"], ["Men", "/men"],
            ["The House", "/about"], ["Craftsmanship", "/craftsmanship"],
            ["Private Appointment", "/appointment"], ["Account", "/account"],
          ].map(([label, path]) => <Link className="block border-b border-[#c9beb2] py-4 font-display text-2xl" key={path} to={path}>{label}</Link>)}
        </nav>
      )}
    </header>
  );
}

export function SiteFooter() {
  return (
    <footer className="bg-[#1c1714] px-6 pb-8 pt-20 text-[#eee7dc] md:px-10 lg:px-16">
      <div className="mx-auto max-w-[1600px]">
        <div className="grid gap-14 border-b border-white/15 pb-16 lg:grid-cols-[1.4fr_0.6fr]">
          <div><p className="eyebrow !text-[#a89c90]">Private appointments & new releases</p><p className="mt-6 font-display text-5xl md:text-7xl">Join the house.</p></div>
          <form className="self-end" onSubmit={(event) => event.preventDefault()}>
            <label className="text-[10px] tracking-[0.22em] uppercase" htmlFor="footer-email">Email address</label>
            <div className="mt-4 flex border-b border-white/50"><input className="min-w-0 flex-1 bg-transparent py-4 text-sm outline-none placeholder:text-white/35" id="footer-email" placeholder="you@example.com" type="email" /><button className="group px-3"><Arrow /></button></div>
          </form>
        </div>
        <div className="grid gap-10 py-10 text-[10px] tracking-[0.15em] text-white/60 uppercase md:grid-cols-4">
          <div className="space-y-3"><p className="text-white">The house</p><Link className="block hover:text-white" to="/about">About</Link><Link className="block hover:text-white" to="/craftsmanship">Craftsmanship</Link><Link className="block hover:text-white" to="/contact">Contact</Link></div>
          <div className="space-y-3"><p className="text-white">Client services</p><Link className="block hover:text-white" to="/appointment">Private appointment</Link><Link className="block hover:text-white" to="/shipping">Shipping & returns</Link><Link className="block hover:text-white" to="/account">My account</Link></div>
          <div className="space-y-3"><p className="text-white">Legal</p><Link className="block hover:text-white" to="/privacy">Privacy</Link><Link className="block hover:text-white" to="/terms">Terms</Link></div>
          <div className="space-y-3 md:text-right"><p className="text-white">Follow</p><a className="block hover:text-white" href="#">Instagram</a><a className="block hover:text-white" href="#">Pinterest</a></div>
        </div>
        <p className="border-t border-white/10 pt-7 text-[9px] tracking-[0.15em] text-white/40 uppercase">© 2025 House of Jaswanth · New Delhi, India</p>
      </div>
    </footer>
  );
}

export function Layout() {
  const { searchOpen, bagOpen } = useStore();
  useEffect(() => {
    document.body.style.overflow = searchOpen || bagOpen ? "hidden" : "";
    return () => { document.body.style.overflow = ""; };
  }, [searchOpen, bagOpen]);
  return (
    <>
      <SiteHeader />
      <Outlet />
      <SiteFooter />
      <SearchDrawer />
      <BagDrawer />
    </>
  );
}
