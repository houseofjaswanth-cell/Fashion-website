import { createBrowserRouter } from "react-router";
import { Layout } from "../components/Layout";
import Home from "../pages/Home";
import { ProductPage, ShopPage, WishlistPage } from "../pages/Shop";
import { AccountPage, AppointmentPage, CheckoutPage, OrderConfirmation } from "../pages/Commerce";
import { ContactPage, EditorialPage, NotFound, PolicyPage } from "../pages/Editorial";

export const router = createBrowserRouter([
  { path: "/", Component: Home },
  {
    Component: Layout,
    children: [
      { path: "collections", element: <ShopPage /> },
      { path: "women", element: <ShopPage category="Women" /> },
      { path: "men", element: <ShopPage category="Men" /> },
      { path: "product/:id", Component: ProductPage },
      { path: "wishlist", Component: WishlistPage },
      { path: "checkout", Component: CheckoutPage },
      { path: "order-confirmation", Component: OrderConfirmation },
      { path: "account", Component: AccountPage },
      { path: "appointment", Component: AppointmentPage },
      { path: "about", element: <EditorialPage page="about" /> },
      { path: "craftsmanship", element: <EditorialPage page="craftsmanship" /> },
      { path: "contact", Component: ContactPage },
      { path: "shipping", element: <PolicyPage page="shipping" /> },
      { path: "privacy", element: <PolicyPage page="privacy" /> },
      { path: "terms", element: <PolicyPage page="terms" /> },
      { path: "*", Component: NotFound },
    ],
  },
]);
