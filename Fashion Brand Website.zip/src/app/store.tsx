import { createContext, useContext, useMemo, useState, type ReactNode } from "react";
import { products, type Product } from "../data/products";

type CartItem = { product: Product; size: string; quantity: number };

type StoreContextValue = {
  bag: CartItem[];
  wishlist: string[];
  bagOpen: boolean;
  searchOpen: boolean;
  addToBag: (product: Product, size: string) => void;
  updateQuantity: (id: string, quantity: number) => void;
  removeFromBag: (id: string) => void;
  toggleWishlist: (id: string) => void;
  setBagOpen: (open: boolean) => void;
  setSearchOpen: (open: boolean) => void;
};

const StoreContext = createContext<StoreContextValue | null>(null);

export function StoreProvider({ children }: { children: ReactNode }) {
  const [bag, setBag] = useState<CartItem[]>([]);
  const [wishlist, setWishlist] = useState<string[]>([]);
  const [bagOpen, setBagOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);

  const value = useMemo<StoreContextValue>(
    () => ({
      bag,
      wishlist,
      bagOpen,
      searchOpen,
      addToBag(product, size) {
        setBag((current) => {
          const found = current.find((item) => item.product.id === product.id && item.size === size);
          return found
            ? current.map((item) =>
                item === found ? { ...item, quantity: item.quantity + 1 } : item,
              )
            : [...current, { product, size, quantity: 1 }];
        });
        setBagOpen(true);
      },
      updateQuantity(id, quantity) {
        setBag((current) =>
          current
            .map((item) => (item.product.id === id ? { ...item, quantity } : item))
            .filter((item) => item.quantity > 0),
        );
      },
      removeFromBag(id) {
        setBag((current) => current.filter((item) => item.product.id !== id));
      },
      toggleWishlist(id) {
        setWishlist((current) =>
          current.includes(id) ? current.filter((item) => item !== id) : [...current, id],
        );
      },
      setBagOpen,
      setSearchOpen,
    }),
    [bag, wishlist, bagOpen, searchOpen],
  );

  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>;
}

export function useStore() {
  const value = useContext(StoreContext);
  if (!value) throw new Error("useStore must be used within StoreProvider");
  return value;
}

export const findProduct = (id?: string) => products.find((product) => product.id === id);
